public class ConcatenarString1 {
	public static void main(String[] args) {
		String nome, primeiroNome = "Ricardo", sobreNome = "Freitas";
		nome = "Nome =  " + primeiroNome + " de " + sobreNome;
		System.out.println(nome);
		// Impress�o: Nome = Ricardo de Freitas
	}
}
