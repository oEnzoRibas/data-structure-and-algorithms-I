
public class Pessoa {
	// Atributos da classe
	String nome;
	int anoNasc;

	// M�todos da classe
	public void ImprimePessoa() {
		System.out.println("Nome: " + this.nome);
		System.out.println("Ano Nascimento: " + this.anoNasc);
	}
}
