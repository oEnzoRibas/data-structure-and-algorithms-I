public class ContagemRegressiva2 {
	public static void main(String[] args) {
		for (int aux = 5; aux >= 0; aux--)
			System.out.println("Aux = " + aux);
	}
}
