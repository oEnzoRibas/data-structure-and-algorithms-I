public class ConcatenarString2 {
	public static void main(String[] args) {
		String soma;
		soma = "Soma =  " + 5 + 15 + 3;
		System.out.println(soma);
		// Impress�o: Soma = 5153
		soma = "Soma =  " + (5 + 15 + 3);
		System.out.println(soma);
		// Impress�o: Soma = 23
	}
}
