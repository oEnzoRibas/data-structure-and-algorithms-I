public class ContagemRegressiva1 {
	public static void main(String[] args) {
		for (int aux = 5; aux >= 0; aux += -1)
			System.out.println("Aux = " + aux);
	}
}
