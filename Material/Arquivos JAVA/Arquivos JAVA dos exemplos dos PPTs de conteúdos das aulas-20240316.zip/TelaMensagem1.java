import javax.swing.JOptionPane; 
public class TelaMensagem1 {
   public static void main(String[] args) {
      JOptionPane.showMessageDialog(null,
         "Bem vindo ao JOptionPane!", 
         "Aula de Java",
         JOptionPane.INFORMATION_MESSAGE);
   }
}

