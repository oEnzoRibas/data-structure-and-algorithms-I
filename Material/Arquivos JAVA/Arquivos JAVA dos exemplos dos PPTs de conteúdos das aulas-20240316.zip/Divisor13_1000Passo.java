public class Divisor13_1000Passo {
	public static void main(String[] args) {
      for (int divisor=13; divisor<=1000; divisor+=13)
        System.out.print(divisor + " � divisor por 13");
   }
}
